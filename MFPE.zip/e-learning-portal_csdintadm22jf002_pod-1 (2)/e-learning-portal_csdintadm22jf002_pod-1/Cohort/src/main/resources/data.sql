insert into courses values (1, 'Java Fundamentals Learning ', 'Java', 2);
insert into courses values (2, 'C++ Programming for beginner', 'C++', 3);
insert into courses values (3, 'Master MySql','SQL', 1);

insert into cohort values (1, 30, '2022-07-10', 2, '2022-06-10' , 1);
insert into cohort values (2, 60, '2022-06-12', 2, '2022-05-16' , 2);
insert into cohort values (3, 15, '2021-07-10', 2, '2022-06-19' , 3);