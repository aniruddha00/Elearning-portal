package com.cts.cohort.exception;

public class CohortAlreadyExistException extends Exception{
	public CohortAlreadyExistException(String msg) {
		super(msg);
	}
}
