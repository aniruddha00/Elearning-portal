package com.cts.cohort;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CohortApplicationTests {

	@Test
	void contextLoads() {
	}

}
