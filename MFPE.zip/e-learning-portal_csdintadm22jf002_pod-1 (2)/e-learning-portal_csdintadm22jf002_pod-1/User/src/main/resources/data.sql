insert into user values (1, 4, 'admin@gmail.com', 'admin', 'admin', 'admin', 'admin');
insert into user values (2, 4, 'student@gmail.com', 'student', 'student', 'student', 'student');
insert into user values (3, 4, 'instructor@gmail.com', 'instructor', 'instructor', 'instructor', 'instructor');
insert into user values (4, 1, 'matu@gmail.com', 'matu', 'matu', 'sweet', 'admin');
insert into user values (5, 3, 'laxmikant@gmail.com', 'Laxmikant', 'Surve', 'abc5', 'Student');
insert into user values (6, 1, 'aniruddha@gmail.com', 'Aniruddha', 'Dhatrak', 'abc4', 'Instructor');
insert into user values (7, 2, 'tanishka@gmail.com', 'Tanishka', 'Bhatia', 'abc1', 'Instructor');
insert into user values (8, 2, 'avnish@gmail.com', 'Avnish', 'Kumar', 'abc2', 'Student');
insert into user values (9, 1, 'prashanth@gmail.com', 'Kyasarla', 'Prashanth', 'abc3', 'Student');


insert into feedback values(1, 'Very Good Course', 2);
insert into feedback values(2, 'Good Course', 3);
insert into feedback values(3, 'Needs Changes', 5);

--insert into feedback values(1, 'Very Good Course', 2, 2);
--insert into feedback values(2, 'Good Course', 3, 5);
--insert into feedback values(3, 'Needs Changes', 5, 9);