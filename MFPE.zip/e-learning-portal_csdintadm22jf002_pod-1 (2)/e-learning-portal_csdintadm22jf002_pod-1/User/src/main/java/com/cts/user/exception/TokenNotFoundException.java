package com.cts.user.exception;

public class TokenNotFoundException extends Exception{
	public TokenNotFoundException(String msg) {
		super(msg);
	}
}
