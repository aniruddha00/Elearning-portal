package com.cts.user.exception;

public class UserAllReadyExistException extends Exception {
	public UserAllReadyExistException(String msg) {
		super(msg);
	}
}
