export class SendFeedback {
    feedbackText!: string;
    user!: UserId;
}

export class UserId {
    userId: any;
}