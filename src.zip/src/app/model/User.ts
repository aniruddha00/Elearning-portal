export class User {
    userId!:number;
    email: string = ''
    password: string = ''
    firstName: string =''
    lastName: string = ''
    userType:string = ''
    cohortId:string=''
}
