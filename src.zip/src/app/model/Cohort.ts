import { Course } from "./Course"


export class  Cohort {
    cohortId!:number
    startDate!:Date
    endDate!:Date
    duration!:number
    instructorId!:number
    courseId!:number
}
