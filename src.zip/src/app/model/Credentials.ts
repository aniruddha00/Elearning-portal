export class Credentials {
    userName : string =''
    password : string=''
    constructor(){}
}