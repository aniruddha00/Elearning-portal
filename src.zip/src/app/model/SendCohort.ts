import { Course } from "./Course"

export class  SendCohort {
    cohortId!:number
    startDate!:Date
    endDate!:Date
    duration!:number
    instructorId!:number
    course!:course;
}
export class course {
    courseId!:number;
}
