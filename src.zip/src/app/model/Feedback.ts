export class Feedback {
    feedbackText!: string;
    studentId!: any;
}