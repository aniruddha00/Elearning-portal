export const environment = {
    production: true,
    name: '(PROD)',
    usersBaseUrl: 'http://host.docker.internal:8084',
    authBaseUrl: 'http://host.docker.internal:8081',
    cohortBaseUrl: 'http://host.docker.internal:8082'
};
