export const environment = {
    production: false,
    name: '(DEV)',
    usersBaseUrl: 'http://localhost:8084',
    authBaseUrl: 'http://localhost:8081',
    cohortBaseUrl: 'http://localhost:8082'
};
