export const environment = {
    production: false,
    name: '(EXAMPLE)',
    usersBaseUrl: '',
    authBaseUrl: '',
    cohortBaseUrl: ''
};